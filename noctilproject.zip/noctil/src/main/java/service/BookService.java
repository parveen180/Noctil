package service;

import java.util.List;

import entity.Book;

public interface BookService {
Book saveBook(Book book);
List<Book>getAllBooks();
Book getBookById(Long id);
 void deleteBook(Long id);
}
