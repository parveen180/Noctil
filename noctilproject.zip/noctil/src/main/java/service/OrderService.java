package service;

import java.util.List;

import entity.Order;

public interface OrderService {
	Order createOrder(Long studentId, Long bookId);
    Order returnBook(Long orderId);
    List<Order> getAllOrders();
    Order getOrderById(Long id);
	
}
