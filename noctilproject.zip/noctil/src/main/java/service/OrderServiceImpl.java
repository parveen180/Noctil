package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entity.Book;
import entity.Order;
import entity.Student;
import repository.BookRepository;
import repository.OrderRepository;
import repository.StudentRepository;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + id));
    }

    @Override
    public Order createOrder(Long studentId, Long bookId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        if (book.getCount() <= 0) {
            throw new RuntimeException("Book not available");
        }

        book.setCount(book.getCount() - 1);
        bookRepository.save(book);

        Order order = new Order();
        order.setBook(book);
        order.setStudent(student);

        return orderRepository.save(order);
    }

    @Override
    public Order returnBook(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        if (order.isReturned()) {
            throw new RuntimeException("Book already returned");
        }

        Book book = order.getBook();
        book.setCount(book.getCount() + 1);
        bookRepository.save(book);
        orderRepository.delete(order);



       
    }}