package library;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import entity.Book;
import repository.BookRepository;

public class DataLoader {
	@Bean
    CommandLineRunner loadData(BookRepository bookRepository) {
        return args -> {
            bookRepository.save(new Book(null, "Spring Boot Basics", 5));
            bookRepository.save(new Book(null, "Java for Beginners", 3));
            bookRepository.save(new Book(null, "Microservices Architecture", 2));
        };
    }
}

