package controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import entity.Book;
import service.BookServiceImpl;

@RestController
@RequestMapping("/api/books")
public class BookController {
@Autowired BookServiceImpl bookService;

@PostMapping
public ResponseEntity<Book> createBook(@RequestBody Book book) {
    Book created = bookService.saveBook(book);
    return ResponseEntity.ok(created);
}
@GetMapping
public List<Book> getAllBooks() {
    return bookService.getAllBooks();
}

@GetMapping("/{id}")
public Optional<Book> getBookById(@PathVariable Long id) {
    return Optional.ofNullable(bookService.getBookById(id));
}
@DeleteMapping("/{id}")
public String deleteBook(@PathVariable Long id) {
    bookService.deleteBook(id);
    return "Book deleted successfully";
}
}
