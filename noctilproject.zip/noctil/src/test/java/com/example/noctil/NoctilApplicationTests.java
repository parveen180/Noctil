package com.example.noctil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoctilApplicationTests {

	@Test
	void contextLoads() {
	}

}
